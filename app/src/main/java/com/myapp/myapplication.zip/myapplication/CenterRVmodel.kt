package com.myapp.myapplication

 data class CenterRVmodel(
         val centerName:String,
         val centeraddress:String,
         val centerFromtime:String,
         val centerTotime:String,
         val fee_type: Int,
         val agelimit: String,
         val vaccinename: Int,
         val availablecapacity: String
 )